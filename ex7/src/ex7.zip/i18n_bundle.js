const BUNDLE = {
	default: {
		nameDescription: "The name of the event is ",
		dateDescription: "and will be arranged on "
	},	
	en: {
		nameDescription: "The name of the event is ",
		dateDescription: "and will be arranged on "
	},	
	fi: {
		nameDescription: "Tapahtuman nimi on ",
		dateDescription: "ja järjestetään "
	},
	de: {
		nameDescription: "Der Name der Veranstaltung heisst ",
		dateDescription: " und findet statt am "
	}
}

export default BUNDLE;